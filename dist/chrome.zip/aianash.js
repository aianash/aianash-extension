'use strict';

var TEMPLATE = '<div>\n' + '  <p>This is aianash chrome extension</p>\n' + '</div>';
"use strict";

$document.ready(function () {});